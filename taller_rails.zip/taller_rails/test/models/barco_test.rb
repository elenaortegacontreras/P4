require "test_helper"

class BarcoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
