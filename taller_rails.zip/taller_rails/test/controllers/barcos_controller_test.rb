require "test_helper"

class BarcosControllerTest < ActionDispatch::IntegrationTest
  setup do
    @barco = barcos(:one)
  end

  test "should get index" do
    get barcos_url
    assert_response :success
  end

  test "should get new" do
    get new_barco_url
    assert_response :success
  end

  test "should create barco" do
    assert_difference("Barco.count") do
      post barcos_url, params: { barco: { barcoGrande: @barco.barcoGrande, probabilidad: @barco.probabilidad, puntuacion: @barco.puntuacion, usuario_id: @barco.usuario_id } }
    end

    assert_redirected_to barco_url(Barco.last)
  end

  test "should show barco" do
    get barco_url(@barco)
    assert_response :success
  end

  test "should get edit" do
    get edit_barco_url(@barco)
    assert_response :success
  end

  test "should update barco" do
    patch barco_url(@barco), params: { barco: { barcoGrande: @barco.barcoGrande, probabilidad: @barco.probabilidad, puntuacion: @barco.puntuacion, usuario_id: @barco.usuario_id } }
    assert_redirected_to barco_url(@barco)
  end

  test "should destroy barco" do
    assert_difference("Barco.count", -1) do
      delete barco_url(@barco)
    end

    assert_redirected_to barcos_url
  end
end
