require "application_system_test_case"

class ProjectDevelopersTest < ApplicationSystemTestCase
  setup do
    @project_developer = project_developers(:one)
  end

  test "visiting the index" do
    visit project_developers_url
    assert_selector "h1", text: "Project developers"
  end

  test "should create project developer" do
    visit project_developers_url
    click_on "New project developer"

    fill_in "Developer", with: @project_developer.developer_id
    fill_in "Fin", with: @project_developer.fin
    fill_in "Inicio", with: @project_developer.inicio
    fill_in "Project", with: @project_developer.project_id
    click_on "Create Project developer"

    assert_text "Project developer was successfully created"
    click_on "Back"
  end

  test "should update Project developer" do
    visit project_developer_url(@project_developer)
    click_on "Edit this project developer", match: :first

    fill_in "Developer", with: @project_developer.developer_id
    fill_in "Fin", with: @project_developer.fin
    fill_in "Inicio", with: @project_developer.inicio
    fill_in "Project", with: @project_developer.project_id
    click_on "Update Project developer"

    assert_text "Project developer was successfully updated"
    click_on "Back"
  end

  test "should destroy Project developer" do
    visit project_developer_url(@project_developer)
    click_on "Destroy this project developer", match: :first

    assert_text "Project developer was successfully destroyed"
  end
end
