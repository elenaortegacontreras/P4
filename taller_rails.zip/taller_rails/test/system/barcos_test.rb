require "application_system_test_case"

class BarcosTest < ApplicationSystemTestCase
  setup do
    @barco = barcos(:one)
  end

  test "visiting the index" do
    visit barcos_url
    assert_selector "h1", text: "Barcos"
  end

  test "should create barco" do
    visit barcos_url
    click_on "New barco"

    check "Barcogrande" if @barco.barcoGrande
    fill_in "Probabilidad", with: @barco.probabilidad
    fill_in "Puntuacion", with: @barco.puntuacion
    fill_in "Usuario", with: @barco.usuario_id
    click_on "Create Barco"

    assert_text "Barco was successfully created"
    click_on "Back"
  end

  test "should update Barco" do
    visit barco_url(@barco)
    click_on "Edit this barco", match: :first

    check "Barcogrande" if @barco.barcoGrande
    fill_in "Probabilidad", with: @barco.probabilidad
    fill_in "Puntuacion", with: @barco.puntuacion
    fill_in "Usuario", with: @barco.usuario_id
    click_on "Update Barco"

    assert_text "Barco was successfully updated"
    click_on "Back"
  end

  test "should destroy Barco" do
    visit barco_url(@barco)
    click_on "Destroy this barco", match: :first

    assert_text "Barco was successfully destroyed"
  end
end
