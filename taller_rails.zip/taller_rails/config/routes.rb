Rails.application.routes.draw do
  resources :comentarios
  resources :barcos
  resources :usuarios
  resources :project_developers do
    collection do
      get 'teams'
    end
  end

  resources :developers
  resources :projects

  root to: "usuarios#index"
end
