class CreateProjectDevelopers < ActiveRecord::Migration[7.0]
  def change
    create_table :project_developers do |t|
      t.date :inicio, null: false 
      t.date :fin
      t.belongs_to :project, null: false, foreign_key: true
      t.belongs_to :developer, null: false, foreign_key: true

      t.timestamps
    end
  end
end
