class RemoveProjectIdFromDevelopers < ActiveRecord::Migration[7.0]
  def change
    remove_column :developers, :project_id, :integer
  end
end
