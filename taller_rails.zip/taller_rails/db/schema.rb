# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# This file is the source Rails uses to define your schema when running `bin/rails
# db:schema:load`. When creating a new database, `bin/rails db:schema:load` tends to
# be faster and is potentially less error prone than running all of your
# migrations from scratch. Old migrations may fail to apply correctly if those
# migrations use external dependencies or application code.
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema[7.0].define(version: 2023_05_23_143304) do
  create_table "barcos", charset: "latin1", force: :cascade do |t|
    t.float "probabilidad"
    t.integer "puntuacion"
    t.boolean "barcoGrande"
    t.bigint "usuario_id", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["usuario_id"], name: "index_barcos_on_usuario_id"
  end

  create_table "comentarios", charset: "latin1", force: :cascade do |t|
    t.string "texto"
    t.bigint "usuario_id", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["usuario_id"], name: "index_comentarios_on_usuario_id"
  end

  create_table "developers", charset: "latin1", force: :cascade do |t|
    t.string "name"
    t.string "surname"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["surname"], name: "index_developers_on_surname"
  end

  create_table "project_developers", charset: "latin1", force: :cascade do |t|
    t.date "inicio", null: false
    t.date "fin"
    t.bigint "project_id", null: false
    t.bigint "developer_id", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["developer_id"], name: "index_project_developers_on_developer_id"
    t.index ["project_id"], name: "index_project_developers_on_project_id"
  end

  create_table "projects", charset: "latin1", force: :cascade do |t|
    t.string "name", null: false
    t.text "info"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["name"], name: "index_projects_on_name", unique: true
  end

  create_table "usuarios", charset: "latin1", force: :cascade do |t|
    t.string "nombre"
    t.string "contrasenia"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  add_foreign_key "barcos", "usuarios"
  add_foreign_key "comentarios", "usuarios"
  add_foreign_key "project_developers", "developers"
  add_foreign_key "project_developers", "projects"
end
