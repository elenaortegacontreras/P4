class Comentario < ApplicationRecord
  belongs_to :usuario
end
