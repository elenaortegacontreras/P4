class Usuario < ApplicationRecord
end
