class Developer < ApplicationRecord
  belongs_to :project
  
  def whole_name
    devolver = name + " " + surname
  end
end
