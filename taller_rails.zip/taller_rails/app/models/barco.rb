class Barco < ApplicationRecord
  belongs_to :usuario
end
